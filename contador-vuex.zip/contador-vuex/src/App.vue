<template>
  <div id="app">
    <img alt="Vue logo" src="./assets/logo.png">
    <p>{{ conteo }}</p>
    <button v-on:click="incremento()">aumentar</button>
    <button v-on:click="decremento()">disminuir</button>
  </div>
</template>

<script>
  export default {
        name: 'App',
        computed: {
            conteo(){
                return this.$store.state.contador
            }
        },
        methods:{
            incremento() {
                this.$store.commit('incrementar')
            },
            decremento() {
              this.$store.commit('decrecer')
            }
        }
    }
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
